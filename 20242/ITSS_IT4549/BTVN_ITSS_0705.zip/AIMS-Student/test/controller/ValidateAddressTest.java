package controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class ValidateAddressTest {

    private PlaceOrderController placeOrderController;

    @BeforeEach
    void setUp() throws Exception {
        placeOrderController = new PlaceOrderController();
    }

    @ParameterizedTest
    @CsvSource({ "123 Main St, true", "456 Elm St, true", "@1234^%&&, false", "hanoi thanh xuan, true", ", false"})

    void test(String address, boolean expected) {
        boolean isValided = placeOrderController.validateAddress(address);
        assertEquals(expected, isValided);
    }

}
