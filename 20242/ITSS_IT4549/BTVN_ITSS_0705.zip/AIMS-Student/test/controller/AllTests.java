package controller;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    ValidateNameTest.class,
    ValidatePhoneNumberTest.class,
    ValidateAddressTest.class,
})
public class AllTests {
}
