import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class TestJunit {
    @Test
    public void Setup() {
        String str = "I am done with JUnit setup";
        assertEquals("I am done with JUnit setup", str);
    }
}
