import java.util.StringTokenizer;

public class StringUtils {
    private StringUtils() {}

    public static String reverseWords(String str) {
        StringBuilder result = new StringBuilder();
        StringTokenizer tokenizer = new StringTokenizer(str, " ");
        while (tokenizer.hasMoreTokens()) {
            StringBuilder sb = new StringBuilder();
            sb.append(tokenizer.nextToken());
            sb.reverse();

            result.append(sb);
            result.append(" ");
        }
        return result.toString();
    }

    public static int countWords (String str) {
        StringTokenizer tokenizer = new StringTokenizer(str.trim(), " ");
        return tokenizer.countTokens() + 1;
    }
}