import static org.junit.Assert.*;
import org.junit.*;

public class StringUtilsTest {
    @Test
    public void testReserveWords() {
        assertEquals("oof", StringUtils.reverseWords("foo"));
        assertEquals("ym eman si nahk", StringUtils.reverseWords("my name is khan"));
        assertEquals("!zaB", StringUtils.reverseWords("Baz!"));
    }

    @Test
    public void testCountWords() {
        assertEquals(3, StringUtils.countWords("Hello The World"));
        assertEquals(2, StringUtils.countWords("Test Case"));
    }
}