import static org.junit.Assert.*;
import java.util.Arrays;
import java.util.Collection;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameter;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class ParameterizedTest {
//    private int number1;
//    private int number2;
//    private int sum;

    @Parameter(value = 0)
    public int number1;

    @Parameter(value = 1)
    public int number2;

    @Parameter(value = 2)
    public int sum;

//    public ParameterizedTest(int number1, int number2, int sum) {
//        this.number1 = number1;
//        this.number2 = number2;
//        this.sum = sum;
//    }

    @Parameters(name = "{index}: testAdd({0}+{1}) = {2}")
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][] {
//                { 1, 2, 3 },
//                { 2, 2, 4 },
//                { 8, -2, 6 },
//                { -7, 8, 1 },
//                { -9, -1, -10 }
                { 1, 1, 2 },
                { 2, 2, 4 },
                { 8, -2, 6 },
                { -7, 8, 1 },
                { -9, -1, -10 }
        });
    }

    @Test
    public void test_addTwoNumbers() {
        assertEquals(sum, MathUtils.add(number1, number2));
    }
}